<?php

$dbHost = 'LocalHost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'restaurante';

$conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

?>